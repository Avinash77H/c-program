#include<stdio.h>
void main()
{
       float dollor,rupees;
   
   printf("enter a dollor:");
   scanf("%f",&dollor);
  
    rupees=83.25*dollor;
  
  printf("rupees:%.2f\n",rupees);
}