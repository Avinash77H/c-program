#include <stdio.h>

int main()
{
    char i;
    for (i='a';i<='z';++i)
    {
        printf("%c\t",i);
    }

    return 0;
}
