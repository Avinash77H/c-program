#include<stdio.h>
void main()
{
   float inches,centimeter;
   
   printf("enter a inches:");
   scanf("%f",&inches);
 
  centimeter=2.54*inches;
  
  printf("centimeter:%.2f\n",centimeter);
    
}