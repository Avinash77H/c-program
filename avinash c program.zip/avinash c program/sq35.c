
#include <stdio.h>
#include<math.h>


int main()
{  char i;
    
     for(i='A'; i<='Z';i=i+2) printf("%c\n",i);
         
     
     
     

    return 0;
}
