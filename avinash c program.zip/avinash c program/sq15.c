#include <stdio.h>
int main()
{ int a;
   printf("enter a value of a:");
   scanf("%d",&a);
   
         if (a>0)
    {
        printf("value is positive:%d",a);
       
    }
    else
    {
        printf("value is negative:%d",a);
        
    }
    return 0;
}
