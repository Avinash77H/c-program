#include<stdio.h>
void main()
{
       float feet,inches;
   
   printf("enter a feet:");
   scanf("%f",&feet);
  
  
  inches=12*feet;
  
  printf("inches:%.2f\n",inches);
          
}