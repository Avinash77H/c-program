#include <stdio.h>
int main()
{   float side,formula;
    printf("enter value of side:");
    scanf("%f",&side);
    
    formula=side*side;
    
    printf("area of squre:%.2f",formula);

    return 0;
}
